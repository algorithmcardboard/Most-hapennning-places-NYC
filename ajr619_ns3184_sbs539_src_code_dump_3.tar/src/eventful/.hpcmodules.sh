#!/bin/bash
module load virtualenv/12.1.1
module load libxml2/intel/2.9.1
module load libxslt/intel/1.1.28
